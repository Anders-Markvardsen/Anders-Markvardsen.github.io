"""

!  Python script that converts a .dil file into a .hkl_weight file. 
!
!  Note a scale_intensities parameter is introduced somewhere in the code
!  below, which can be used to scale up/down the intensities from the .dil's
!  file. Note also there is definitely room for improving this script further.
!
!  USAGE: python convert_dil.py somename.dil somename.hkl_weight
!
!         where:
!
!                somename.dil   - is changed to the name of the .dil
!                                 file you want to convert
!                out.hkl_weight - is the .hkl_weight file returned by
!                                 this python script
!
!  CREDITS: This script contains a copy of the code for the ciimatrix 
!           class that forms part of the Linarp library. Hence the 
!           reason for the copyright note below.
!
!  AUTHORS: Jon Wright
!           Anders Markvardsen
!           Stuart Ansell
  
"""


"""

!  Copyright (C) 2004 by Jonathan Wright
!     Grenoble, France
!     email: wright@esrf.fr
!
!   This file is part of Linarp.
!
!   Linarp is free software; you can redistribute it and/or modify
!   it under the terms of the GNU General Public License as published by
!   the Free Software Foundation; either version 2 of the License, or
!   (at your option) any later version.
!
!   Linarp is distributed in the hope that it will be useful,
!   but WITHOUT ANY WARRANTY; without even the implied warranty of
!   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
!   GNU General Public License for more details.
!
!   You should have received a copy of the GNU General Public License
!   along with Linarp; if not, write to the Free Software
!   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

"""


import math,sys
import array

def numzeroFloat1D(Index):
## Function to replace Numeric::
    out = array.array('d')
    for i in range(Index):
        out.append(float(0.0))
    return out

def numzeroInt(Index):
    out = array.array('i')
    for i in range(Index):
        out.append(int(0))
    return out

def dot(A,B):
##
## Test A == same length as B etc....
## 
    sum=0.0
    for i in len(A):
        sum+=A[i]*B[i]
    return sum


def numzeroFloat2D(m, n):
#Generate two dimensional array
    arr = [None] * m
    for i in range(m):
        arr[i] = [float(0.0)] * n
    return arr   


class ciimatrix:

   def __init__(self,filename):
      """
      Makes a python object representing the information coming from
      a DILS refinement in the MPRODD computer program
      Has a matrix which is the least squares matrix to be inverted
      during a Pawley refinement and also a set of non-intensity
      variables
      """
      f=open(filename,"r")
      items=f.readline().split()
      self.ni=int(items[0])
      self.nv=int(items[3])
      self.nt=self.ni+self.nv
      junk=f.readline()
      self.Ihkl = numzeroFloat1D(self.ni)
      self.HKL = numzeroFloat2D(self.ni, 3)
      self.IP = numzeroInt(self.nt)
      for i in range(self.ni):
        try:
         items=f.readline().split()
         self.IP[i]=int(items[1])
         self.HKL[i]=[int(items[3]),int(items[4]),int(items[5])]
         self.Ihkl[i]=float(items[-1])
        except ValueError:
           print items
           print "Sorry - problems interpreting your file"
           sys.exit()
      self.rhs = numzeroFloat1D(self.nt)
      self.rhs[0:self.ni]=self.Ihkl
      for i in range(self.nv):
         items=f.readline().split()
         self.IP[self.ni+i]=int(items[1])
      print f.readline(),   
      self.matrix = numzeroFloat1D(self.IP[-1])
      self.matrix[0]=float(f.readline())
      for i in range(1,self.IP[-1]):
         self.matrix[i]=float(f.readline())
      f.close()
      print "Number of entries in matrix",self.IP[-1]
      print "Number of intensities=",self.ni,"Total vars",self.nt
      print "Percentage full=",self.IP[-1]*100.0/self.ni/self.ni
      self.ciimat=None
      self.L=None
      self.damp=0.1
      self.vecy = numzeroFloat1D(self.nt)


   def makesquare(self):
      """
      Produces a dense square matrix from the sparse one
      which is produced by the refinement program
      """
      mat = numzeroFloat2D(self.nt,self.nt)
      mat[0][0]=self.matrix[0]
      for i in range(1,self.nt):
        j=0
        while (self.IP[i]-j) > self.IP[i-1]:
           try:
              mat[i-j][i]=self.matrix[self.IP[i]-j-1]
              mat[i][i-j]=self.matrix[self.IP[i]-j-1]
              j+=1
           except IndexError:
              print i,j,self.IP[i],self.IP[i-1],\
                ciimat.shape,matrix.shape,self.IP[i]-j,i-j
              print "Trouble making a square matrix from the sparse one"
              sys.exit()
      return mat   

      
def makesquare_without_zero_diagonal_weights(mat_in, ni):
      """
      Takes as input a ciimatrix.makesquare() and produce a square matrix
      with no zero diagonal elements
      """
      
      # determine how many none-zero diagonal elements 
      old_size = ni
      
      # flag_array holds zeros and onces: zero means 
      # flag_array=Numeric.zeros(old_size,Numeric.Int)
      new_size = 0  # initialise new square matrix size
      for i in range(old_size):
         if mat_in[i][i] != 0:
            new_size = new_size + 1
      
      mat_out = numzeroFloat2D(new_size,new_size)

      print "Size of matrix without zero diagonals: ", new_size
      
      i_new = -1
      for i in range(old_size):
         if mat_in[i][i] != 0:
            i_new = i_new + 1
            j_new = -1
            for j in range(old_size):
               if mat_in[j][j] != 0:
                  j_new = j_new + 1
                  #print i_new, j_new
                  mat_out[i_new][j_new] = mat_in[i][j]
            if j_new != new_size-1:
               print j_new
               print "problem j_new"
               sys.exit()
      if i_new != new_size-1:
         print i_new
         print "problem i_new"
         sys.exit()

      return mat_out      


if __name__=="__main__":

   if len(sys.argv) == 1:
       print "Required calling format is: python convert_dil.py somename.dil out.hkl_weight"
       sys.exit()

   testobject=ciimatrix(sys.argv[1])
   f = open(sys.argv[2], 'w')

   my_square_temp = testobject.makesquare()
   my_square = makesquare_without_zero_diagonal_weights(my_square_temp, testobject.ni)
   
   scale_intensities = 100.0  # to optionally scale up/down .dil intensities and weights
   
   ni = len(my_square)
   number_of_corr_elements = 15
   for i in range(ni):
      f.write(str(int(testobject.HKL[i][0])))
      f.write('  ')
      f.write(str(int(testobject.HKL[i][1])))
      f.write('  ')
      f.write(str(int(testobject.HKL[i][2])))
      f.write('  ')
      f.write(str(testobject.Ihkl[i]/scale_intensities))
      f.write('  ')
      f.write(str(scale_intensities*math.sqrt(my_square[i][i])))
      f.write('  ')
      f.write(str(int(i+1)))
      f.write('  ')
      
      for j in range(i+1, i+number_of_corr_elements):
        
         if j < ni:
            dummy = 100*my_square[i][j]/math.sqrt(my_square[i][i]*my_square[j][j])
            
            if dummy > 100:
               dummy = 100.0
            f.write(str(dummy))
         else:
            f.write(str(0.0))
         f.write('  ')
      f.write('\n')
      
   
   f.close()
   sys.exit()
