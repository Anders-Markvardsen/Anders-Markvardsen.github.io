5/12-2007

We (Matt Tucker and Anders Markvardsen) worked on writing some code which allowed 
ExtSym to be called at the end of a GSAS le Bail refinement.

The outcome of this work is the executable gsas_extsym.exe, which you are 
welcome to try out. Notice this executable is in an experimental stage and
will return many output files of which one is the ExtSym table output is 'table.asc'. 

In general we had a number of problems with writing this script since we 
were guessing where to find the information we needed to calculate the 
weight matrix elements from the GSAS le Bail refinement. And since life is finite
we decided enough is enough and so the executable (for which the source
is located in the 'source' directory) is a snapshot of how far we got. 

Included is also a HRPD dataset from Richard Ibberson, Acta Cryst (2006) B62, 
280-286:

  DMS_HRPD_5K_LEB_AND.EXP
  hrp29984.gsa
  28126_ls2.hrpd
  
The dataset is monoclinic (b-axis) and the true extinction symbol for this dataset 
is 'I 1  a  1'. 


INTROSTRUCTIONS FOR RUNNING THE gsas_extsym.exe script can be found on:

  http://www.markvardsen.net/projects/ExtSym/with-known-decom-prog.html#section_gsas

and these instructrions are repeated here for convenience:

  1. Le Bail fit your data using GSAS in a space group with no systematic absent reflections. 

  2. Copy the .exp file generated from step 1. to this directory (plus the data). 

  3. From a command prompt type: gsas_extsym.exe "gsas_directory", where the argument "gsas_directory" 
     is the name of directory where the GSAS executable is located. If this argument is left out this 
     directory name defaults to "c:\gsas\exe". (Note do not end the directory name with a backslash!). 

  4. Follow the instructions of the gsas_extsym.exe script. 

  5. Examine the output returned by ExtSym, i.e. table.asc (for information about how to read a 
     table.asc file, see http://www.markvardsen.net/projects/ExtSym/explain-output.html).