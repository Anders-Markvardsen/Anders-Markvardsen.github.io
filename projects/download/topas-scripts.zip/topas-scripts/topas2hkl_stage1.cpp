#include <iostream>
#include <fstream>
#include <string>
#include <cstdio>

using namespace std;

void print_error(const char*, const char* = " ");

int main(int argc, char* argv[])
{  
  string aLine;

  if ( argc != 3 ) 
    print_error("usage: topas2extsym in_file out_file \n");

  ifstream in_topas( argv[1] );
  if (!in_topas)
    print_error("can't open", argv[1]);

  ofstream out_topas( argv[2] );
  if (!out_topas)
    print_error("can't open", argv[2]);



  string::size_type pos = 0;
  while ( getline(in_topas, aLine, '\n') ) 
  {
    out_topas << aLine << endl;
    if ( ( pos = aLine.find("load hkl_m_d_th2 I") ) != string::npos ) 
    {
      break;
    }
  }

  if (pos == string::npos)
    print_error("No hkl_m_d_th2 topas keyword in", argv[1]);

  getline(in_topas, aLine, '\n'); // skip over '{' topas line
  out_topas << aLine << endl;

  char parameterName[8];
  string paramName;


  int n = 1;
  while ( getline(in_topas, aLine, '\n') ) 
  {
    if ( ( pos = aLine.find("@") ) != string::npos ) 
    {
      sprintf(parameterName, "INT%d", n);
      paramName = parameterName;
      aLine.replace( pos, 1, paramName );
      out_topas << aLine << endl;
      n++;
    }
    else
    {
      out_topas << aLine << endl;
      break;
    }
  }

  while ( getline(in_topas, aLine, '\n') ) 
  {
    out_topas << aLine << endl;
  }

  in_topas.close();
  out_topas.close();

  return 0;
}

void print_error(const char* p, const char* p2) {
  cerr << p << ' ' << p2 << endl;
  exit(1);
}