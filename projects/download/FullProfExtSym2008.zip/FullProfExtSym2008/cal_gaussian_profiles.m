function reflections_updated = cal_gaussian_profiles(reflections, twoTheta_i)
%cal_gaussian_profiles
%
%  Inputs: 
%   reflections: Is assumed to contain the fields:
%                     .twoTheta  - two-theta Bragg values
%                     .FWHM
%   twoTheta_i: The observed two-theta values
%
%  Outputs:
%   reflections_updated: Updated version of the input reflections 
%                        structure with the additional fields:
%                          start - contains the peak start indexes
%                          end     - contains the peak end indexes
%                          profile_val - A cell array, which for each cell 
%                                        contains profile values between 
%                                        the start and end points

left_cutoff = reflections.twoTheta - 6*reflections.FWHM;
right_cutoff = reflections.twoTheta + 6*reflections.FWHM;

num_reflections = length(reflections.FWHM);

start_i = zeros([num_reflections 1]);  % start data point index for each reflections
end_i = zeros([num_reflections 1]);  % end data point index for each reflections
profile_val = cell([num_reflections 1]); % profile values for each reflections


% All peaks for which right_cutoff is to the left of first data point do
% not contribute to the pattern

ok_H = find(right_cutoff > twoTheta_i(1));
if isempty(ok_H)
  error('data 2-theta range does not overlap with HKL 2-theta range');
end


start_H = ok_H(1); % used in the for-loop below

% All peaks for which left_cutoff is to the right of last data point do
% not contribute to the pattern

ok_H = find(left_cutoff < twoTheta_i(end));
if isempty(ok_H)
  error('data 2-theta range does not overlap with HKL 2-theta range');
end

end_H = ok_H(end); % used in the for-loop below


% cal the profile values for each reflection

for i_H = start_H : end_H
  i_to_the_right_of_left_cutoff = find(twoTheta_i > left_cutoff(i_H));
  
  % i_to_the_right_of_left_cutoff should be guaranteed to be none empty
  % because of the screening we did above this for loop
  
  start_i(i_H) = i_to_the_right_of_left_cutoff(1);
  
  i_to_the_left_of_right_cutoff = find(twoTheta_i < right_cutoff(i_H));
  
  end_i(i_H) = i_to_the_left_of_right_cutoff(end);
  
  if start_i(i_H) > end_i(i_H)
    error('start_i bigger than end_i');
  end
  
  z = reflections.twoTheta(i_H) - twoTheta_i(start_i(i_H):end_i(i_H));
  profile_val{i_H} = gaussian(z, reflections.FWHM(i_H));
  
  
end


% prepare the output for this function

reflections_updated = reflections;

reflections_updated.start = start_i;
reflections_updated.end = end_i;
reflections_updated.profile_val = profile_val;
