function fullprof2hkl_weight(CODFIL_prf_IGOR, CODFILn_hkl)
%fullprof2hkl_weight - convert FullProf output into ExtSym input
%
%  This script aim to convert a FullProf Le Bail refinement (as specified
%  in the FullProf parameter file with JBT=2) into a .hkl_weight file.
%
%  In calculating the weight matrix elements this scripts makes the
%  following assumptions:
%
%    1. The LP correction factor equals 1/(2*(sin(theta))^2*cos(theta))
%       which is only truly correct for Bragg-Brentano or Debye-Scherrer
%       geometry and neutrons but hopefully reasonable close for the other
%       cases (see FullProf manual)
%    2. The peak shape is assumed to be Gaussian and have no asymmetry 
%       regardless of the actual peak shape used in the Le Bail refinement.
%    3. The square root of the y-obs read in from the IGOR file 
%       (see below) are taken to be the standard deviations of the y-obs
%
%  Inputs:
%   CODFILn_prf_IGOR: This is the filename of a file FullProf outputs when
%                     prf=2 in the FullProf parameter file. This script
%                     reads the two-theta and y-obs from this file rather
%                     than the raw data file, because unlike the IGOR
%                     format, which is well defined, the raw data format
%                     may like the two-theta in many different ways.
%   CODFILn_hkl: This is another FullProf output file, which to my
%                understanding FullProf always returns. Of interest, it
%                contains the extracted intensities (not corrected for LP
%                and multiplicity) and FWHM values. (See FullProf manual
%                and notice a CODFILn.hkl file is different from a 
%                CODFIL.hkl file!).
%
%  Outputs:
%   This script saves to disk a .hkl_weight file with the name
%   CODFIL.hkl_weight, where CODFIL is the name of the FullProf 
%   CODFIL_prf_IGOR filename minus the extension. 
%
%  Created: 26/6-2007 by A. J. Markvardsen. No copyrights apply, i.e. you
%           can change, copy and modify this source file and the functions
%           it calls as much as you fancy. 


  % Read in intenties, FWHMs etc into structure named reflections. This
  % structure aim to hold information about all the reflections that was
  % used in the FullProf Le Bail refinement. Please see the source file
  % of read_fullprof_hkl() for more info about which fields this function
  % adds to the reflections structure.

  reflections = read_fullprof_hkl(CODFILn_hkl);
  
  
  % Read the raw data (from an IGOR formatted file) into a structure
  
  pattern = read_fullprof_prf_no2(CODFIL_prf_IGOR);
  
  
  % As explained at the top of this file, the variances of the y_obs are
  % assumed to equal y_obs (which implies s.d. = sqrt(y_obs)).
  
  variance = pattern.y_obs;
  
    
  % Add some more fields to reflections structure. That is for each 
  % reflection the function below calculates the start-end points of 
  % the peak and Gaussian profile values in between. The added fields to 
  % the reflections structure are:
  %
  %   start   - An integer array: contains the start positions for the peaks; 
  %   end     - An integer array: contains the start positions for the peaks;
  %   profile_val - A cell array, which for each cell contains the profile
  %                 values between the start and end points
   
  reflections = cal_gaussian_profiles(reflections, pattern.twoTheta);
  
  
  % Create diagonal weight matrix elements
  %
  % First initialization
  
  num_reflections = length(reflections.twoTheta);
  W = zeros([num_reflections num_reflections]);
  
  % Populate the diagonal elements of the weight matrix
  %
  % first introduce some shorthand notation to ease the notation in the
  % code below
  
  s_index = reflections.start; 
  e_index = reflections.end;
  profile_val = reflections.profile_val;
  
  for i = 1 : num_reflections
    W(i, i) = sum(profile_val{i}.^2 ./ ...
      variance(s_index(i):e_index(i)));
  end

  % Populate the off-diagonal weight matrix elements
  
  for i_H = 1 : num_reflections
    for i_K = i_H+1 : num_reflections
      if s_index(i_K) > e_index(i_H)
        break;
      end

      % determine the first and last index values for which the profiles
      % for both reflection i_H and i_K are none zero. 
      
      profile_start_i_H = s_index(i_K)+1-s_index(i_H);
      profile_end_i_K = e_index(i_H)+1-s_index(i_K);
      
      % sum over the above determined none-zero indexes to get the off
      % diagonal weight matrix element between reflection i_H and i_K

      W(i_H, i_K) = sum(profile_val{i_H}(profile_start_i_H:end).* ...
        profile_val{i_K}(1:profile_end_i_K) ./ variance(s_index(i_K):e_index(i_H)));
    end
  end
  
  
  % correct the intensities for LP 
  %
  % Notice assume simple form for LP, see discussion at the top of this
  % file

  twoTheta = reflections.twoTheta * pi / 180;
  theta = twoTheta / 2;
  LP =  1 ./ ...
    ( 2*(sin(theta)).^2 .* cos(theta) );
  
  intensity_mod = reflections.intensity ./ LP;
  
  W = diag(LP)*W*diag(LP);
  
  
  % save hkl_weight file
  
  find_dot = findstr(CODFIL_prf_IGOR, '.');
  
  fid = fopen([CODFIL_prf_IGOR(1:find_dot) 'hkl_weight'], 'w');
  
  for i = 1 : num_reflections
    fprintf(fid,'%5d %5d %5d', reflections.h(i), reflections.k(i), ...
        reflections.l(i));
    fprintf(fid,' %15g %15g %d', intensity_mod(i), sqrt(W(i,i)), i);
    for j = 1 : 14
      if i+j <= num_reflections
        fprintf(fid, ' %5g', W(i,i+j)*100 / sqrt(W(i,i)*W(i+j,i+j))); 
      else
        fprintf(fid, ' %5g', 0);
      end
    end
    
    fprintf(fid,'\n');
  end
  
  fclose(fid);
end