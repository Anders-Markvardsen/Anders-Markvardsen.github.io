function gauss_val = gaussian(x,H)
%gaussian
%
%  Gaussian peak shape function. Copied from the CrysFML library.
%
       %H = par(1);
       ag = 0.93943727869965133377234032841018 / H;
       bg = 2.7725887222397812376689284858327 / (H*H);
       gauss_val = ag* exp(-bg*x.*x);
