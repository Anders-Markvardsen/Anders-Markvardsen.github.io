function data = read_fullprof_prf_no2(CODFIL_prf_IGOR)
%read_fullprof_prf_no2
%
%  Assumes that the prf parameter/flag in the FullProf pcf file is set to 
%  2.
%
%  A .prf (no2) contains the FullProf calculated and observed pattern
%  suitable for the IGOR program (I don't have a clue what this program 
%  does)
%
%  Inputs:
%   CODFIL_prf_IGOR: This is the filename of a file FullProf outputs when
%                    prf=2 in the FullProf parameter (.pcr) file. 
%  Outputs:
%   data: Contains most of the stuff in the CODFIL_prf_IGOR file, that is
%         twoTheta, y_obs and y_cal.
%

fid = fopen(CODFIL_prf_IGOR, 'r');

dummy = fgetl(fid);
dummy = fgetl(fid);
dummy = fgetl(fid);


twoTheta = zeros([1 10000]);
y_obs = zeros([1 10000]);
y_cal = zeros([1 10000]);
i = 0;
while 1
  dummy = fgetl(fid);
  if ~isempty(findstr(dummy, 'END'))
    break;
  end
  i = i + 1;  
  dummy = sscanf(dummy, '%f%f%f%f');
  twoTheta(i) = dummy(1);
  y_obs(i) = dummy(2);
  y_cal(i) = dummy(3);
end

twoTheta = twoTheta(1:i);
y_obs = y_obs(1:i);
y_cal = y_cal(1:i);

fclose(fid);


% If this function is called with no return argument it plots the data
% in the IGOR file

if nargout == 1
  data.twoTheta = twoTheta;
  data.y_obs = y_obs;
  data.y_cal = y_cal;
  return;  
end

plot(twoTheta, y_obs, 'r.');
hold on;
plot(twoTheta, y_cal, 'b--');
hold off;

end