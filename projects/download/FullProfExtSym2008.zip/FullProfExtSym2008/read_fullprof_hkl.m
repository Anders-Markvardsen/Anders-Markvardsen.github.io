function reflections = read_fullprof_hkl(CODFILn_hkl)
%read_fullprof_hkl
%
%  Reads in a FullProf CODFILn.hkl file (NOT a CODFIL.hkl file, see 
%  FullProf manual) and returns its content in a Matlab structure.
%
%  Inputs:
%   CODFILn_hkl: This is the filename of a FullProf output file, which to 
%                my understanding FullProf always returns. For instance, it
%                contains the extracted intensities (not corrected for LP
%                and multiplicity) and FWHM values.
%  Outputs:
%   reflections: Contains most of the stuff in the CODFILn_hkl file
%

fid = fopen(CODFILn_hkl, 'r');
dummy = fgetl(fid);
dummy = fgetl(fid);

reflections.h = zeros([1 10000]);
reflections.k = zeros([1 10000]);
reflections.l = zeros([1 10000]);
reflections.mult = zeros([1 10000]);
reflections.intensity = zeros([1 10000]);
reflections.dontknow1 = zeros([1 10000]);
reflections.twoTheta = zeros([1 10000]);  % Bragg two-theta values
reflections.FWHM = zeros([1 10000]);  % Estimated FWHM of each peak

i = 0;
while 1
  dummy = fgetl(fid);
  
  if dummy == -1 %|| isempty(dummy)
    break;
  end
  i = i + 1;
  a_line = sscanf(dummy, '%d%d%d%d%f%f%f%f%f');
  reflections.h(i) = a_line(1);
  reflections.k(i) = a_line(2);
  reflections.l(i) = a_line(3);
  reflections.mult(i) = a_line(4);
  reflections.intensity(i) = a_line(5);
  reflections.dontknow1(i) = a_line(6);
  reflections.twoTheta(i) = a_line(7);
  reflections.FWHM(i) = a_line(8);
end

reflections.h = reflections.h(1:i);
reflections.k = reflections.k(1:i);
reflections.l = reflections.l(1:i);
reflections.mult = reflections.mult(1:i);
reflections.intensity = reflections.intensity(1:i);
reflections.dontknow1 = reflections.dontknow1(1:i);
reflections.twoTheta = reflections.twoTheta(1:i);
reflections.FWHM = reflections.FWHM(1:i);

fclose(fid);

end